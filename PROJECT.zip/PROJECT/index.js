
var express = require('express');
var mongoose = require('mongoose');
var path = require('path');
var bodyParser = require('body-parser');
var app = express();
var PORT = 9000;
app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json());

app.set('views', path.join(__dirname, 'views'));
app.set('view engine','ejs');

require('./model/flat');

//Connecting to MongoDB
mongoose.connect('mongodb://localhost:27017/building',{useUnifiedTopology:true}, {useNewUrlParser:true});
const db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error'));
db.once('open', function(){
    console.log("We are connected on mongoose!");
});


//connecting with controller
var flatController = require('./controller/flatcontroller.js');
app.get('/', function(req, res){
  res.send('Now, You will see all the bookings.')
})

//Take us to displayflats.ejs
app.get('/flats',flatController.GetAll);

//Take us to addflat.ejs
app.get('/flats/add', function(req,res){
  res.render('addflat.ejs');
});

//Take us to displayflat.ejs
app.post('/flats/display', flatController.Create);

//Take us to updatebooking.ejs
app.get("/flats/edit/(:id)", flatController.Edit);

//Take us from updatebooking.ejs to displayflat.ejs
app.post("/flats/edit",flatController.Update);

//delete
app.get('/flats/delete/:id', flatController.Delete);


app.listen('9000', (err,data)=>{
  console.log('Listening to port 9000');
});